package typing_ninja;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Screen;
import javafx.stage.Stage;

public class TypingApp extends Application {

    private StackPane root;        // Profile 主容器（为叠加弹窗）
    private Scene profileScene;    // Profile 场景（用于从 Lesson History 返回）

    @Override
    public void start(Stage stage) {
        double screenWidth = Screen.getPrimary().getBounds().getWidth();
        double screenHeight = Screen.getPrimary().getBounds().getHeight();

        // ================= Profile 页面 =================
        BorderPane profileLayout = new BorderPane();
        profileLayout.setStyle("-fx-background-color: #0A002C;");

        // 顶部标题
        Label profileTitle = new Label("PROFILE");
        profileTitle.setTextFill(Color.WHITE);
        profileTitle.setFont(Font.font("Jaro", FontWeight.EXTRA_BOLD, 60));
        BorderPane.setAlignment(profileTitle, Pos.CENTER);
        profileLayout.setTop(profileTitle);

        // 左边 Goals 区域
        GridPane goalsPane = new GridPane();
        goalsPane.setHgap(40);
        goalsPane.setVgap(25);
        goalsPane.setPadding(new Insets(20));

        Label header1 = makeWhiteLabel("GOALS");
        Label header2 = makeWhiteLabel("Actual");
        goalsPane.addRow(0, new Label(""), header1, header2);

        // 每行目标
        Label g1v = makeWhiteLabel("3");
        Label a1 = makeGreenLabel("5.3");
        addGoalRow(goalsPane, 1, "Practice hours per week", g1v, a1, "");

        Label g2v = makeWhiteLabel("30 wpm");
        Label a2 = makeGreenLabel("27 wpm");
        addGoalRow(goalsPane, 2, "Target speed", g2v, a2, " wpm");

        Label g3v = makeWhiteLabel("97%");
        Label a3 = makeGreenLabel("98%");
        addGoalRow(goalsPane, 3, "Target accuracy", g3v, a3, "%");

        // 左侧两个绿色按钮
        Button lessonHistoryBtn = new Button("Lesson History");
        styleGreenPill(lessonHistoryBtn);
        lessonHistoryBtn.setOnAction(e -> showLessonHistoryPage(stage)); // 跳转

        Button viewCertificatesBtn = new Button("View Certificates");
        styleGreenPill(viewCertificatesBtn); // 先创建，不跳转

        // 左侧容器：Goals + 两个按钮
        VBox leftBox = new VBox(30, goalsPane, lessonHistoryBtn, viewCertificatesBtn);
        leftBox.setAlignment(Pos.TOP_LEFT);
        BorderPane.setMargin(leftBox, new Insets(80, 0, 0, 100));
        profileLayout.setLeft(leftBox);

        // 右边用户信息
        Label avatar = makeWhiteLabel("👤 Renee");
        avatar.setFont(Font.font("Jaro", FontWeight.BOLD, 22));

        // Renee 左边的铅笔按钮
        Image img = new Image(getClass().getResourceAsStream("/pencil-write-tool-icon.png"));
        ImageView pencilIcon = new ImageView(img);
        pencilIcon.setFitWidth(24);
        pencilIcon.setFitHeight(24);
        Button editUserBtn = new Button();
        editUserBtn.setGraphic(pencilIcon);
        editUserBtn.setStyle("-fx-background-color: transparent;");
        editUserBtn.setOnAction(e -> showEditUserPopup());

        HBox topUserBox = new HBox(10, editUserBtn, avatar);

        Button logoutBtn = new Button("Logout");
        logoutBtn.setStyle("-fx-background-color: #FF6F61; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold;");

        HBox topRight = new HBox(20, topUserBox, logoutBtn);
        topRight.setAlignment(Pos.CENTER_RIGHT);

        Label belt = makeWhiteLabel("Blue belt");
        belt.setFont(Font.font("Jaro", FontWeight.BOLD, 22));

        Label lessons = makeWhiteLabel("Lessons completed: 21");
        Label avg = makeWhiteLabel("Average WPM: 16");
        Label highest = makeGoldLabel("Highest Rating: ★★★★☆");
        Label avgRating = makeGoldLabel("Average Rating: ★★★★☆");

        VBox rightBox = new VBox(30, topRight, belt, lessons, avg, highest, avgRating);
        rightBox.setAlignment(Pos.TOP_RIGHT);
        rightBox.setPadding(new Insets(20));
        BorderPane.setMargin(rightBox, new Insets(80, 100, 0, 0));
        profileLayout.setRight(rightBox);

        // 底部菜单
        Label footer = new Label("MAIN MENU | PROFILE | SETTINGS");
        footer.setTextFill(Color.WHITE);
        footer.setFont(Font.font("Jaro", FontWeight.BOLD, 18));
        BorderPane.setAlignment(footer, Pos.CENTER);
        profileLayout.setBottom(footer);

        // 用 StackPane 包裹 BorderPane，方便加弹窗
        root = new StackPane(profileLayout);
        profileScene = new Scene(root, screenWidth, screenHeight);

        // 初始显示
        stage.setTitle("Typing Ninja");
        stage.setScene(profileScene);
        stage.setFullScreen(true);
        stage.show();
    }

    // 添加一行目标（左边标题，中间目标值，右边实际值）
    private void addGoalRow(GridPane pane, int row, String title, Label goalLabel, Label actualLabel, String unit) {
        Label name = makeWhiteLabel(title);

        // 铅笔按钮
        Image img = new Image(getClass().getResourceAsStream("/pencil-write-tool-icon.png"));
        ImageView pencilIcon = new ImageView(img);
        pencilIcon.setFitWidth(24);
        pencilIcon.setFitHeight(24);

        Button editBtn = new Button();
        editBtn.setGraphic(pencilIcon);
        editBtn.setStyle("-fx-background-color: transparent;");

        editBtn.setOnAction(e -> showEditPopup(goalLabel, unit));

        pane.addRow(row, name, new HBox(10, editBtn, goalLabel), actualLabel);
    }

    // 显示半透明弹窗（编辑目标值）
    private void showEditPopup(Label goalLabel, String unit) {
        VBox popup = new VBox(15);
        popup.setStyle("-fx-background-color: rgba(0,0,0,0.8); -fx-padding: 20; -fx-background-radius: 10;");
        popup.setAlignment(Pos.CENTER);

        TextField input = new TextField();
        input.setPromptText("请输入新的数值 (数字)");

        Button ok = new Button("OK");
        ok.setOnAction(e -> {
            String value = input.getText().trim();
            if (!value.isEmpty()) {
                goalLabel.setText(value + unit);
            }
            root.getChildren().remove(popup);   // 移除弹窗
        });

        popup.getChildren().addAll(new Label("修改目标数值:"), input, ok);
        root.getChildren().add(popup);
    }

    // 显示 Edit User 界面
    private void showEditUserPopup() {
        VBox popup = new VBox(20);
        popup.setStyle("-fx-background-color: #DDDDDD; -fx-padding: 20; -fx-background-radius: 15;");
        popup.setAlignment(Pos.TOP_CENTER);

        // 限制弹窗大小
        popup.setPrefWidth(600);
        popup.setPrefHeight(400);
        popup.setMaxWidth(Region.USE_PREF_SIZE);
        popup.setMaxHeight(Region.USE_PREF_SIZE);

        // 用 StackPane 包裹，保证居中
        StackPane container = new StackPane(popup);
        container.setAlignment(Pos.CENTER);

        // ===== 顶部区域 =====
        Label title = new Label("Edit User");
        title.setFont(Font.font("Jaro", FontWeight.BOLD, 24));

        Button closeBtn = new Button("Back");
        closeBtn.setStyle("-fx-background-color: #7CFC00; -fx-text-fill: black; -fx-font-weight: bold;");
        closeBtn.setOnAction(e -> root.getChildren().remove(container));

        HBox headerBox = new HBox(title, closeBtn);
        HBox.setHgrow(title, Priority.ALWAYS);
        headerBox.setAlignment(Pos.CENTER);
        headerBox.setSpacing(20);
        headerBox.setPadding(new Insets(0, 20, 0, 20));

        // ===== 用户名 =====
        Label usernameLabel = new Label("Renee");
        TextField usernameField = new TextField("Renee");
        usernameField.setVisible(false);
        Button pencil1 = makePencil(() -> {
            if (!usernameField.isVisible()) {
                usernameField.setText(usernameLabel.getText());
                usernameLabel.setVisible(false);
                usernameField.setVisible(true);
                usernameField.requestFocus();
            } else {
                String value = usernameField.getText().trim();
                if (!value.isEmpty()) {
                    usernameLabel.setText(value);
                }
                usernameField.setVisible(false);
                usernameLabel.setVisible(true);
            }
        });
        HBox usernameBox = new HBox(10, new Label("Username:"), usernameLabel, usernameField, pencil1);

        // ===== 密码 =====
        Label passwordLabel = new Label("********");
        TextField passwordField = new TextField("mypassword");
        passwordField.setVisible(false);
        Button pencil2 = makePencil(() -> {
            if (!passwordField.isVisible()) {
                passwordField.setText(passwordField.getText());
                passwordLabel.setVisible(false);
                passwordField.setVisible(true);
                passwordField.requestFocus();
            } else {
                String value = passwordField.getText().trim();
                if (!value.isEmpty()) {
                    passwordLabel.setText("********");
                }
                passwordField.setVisible(false);
                passwordLabel.setVisible(true);
            }
        });
        HBox passwordBox = new HBox(10, new Label("Password:"), passwordLabel, passwordField, pencil2);

        // ===== 安全问题 1 =====
        ComboBox<String> q1 = new ComboBox<>();
        q1.getItems().addAll("City of Birth", "Mother's Maiden Name", "Favorite Teacher", "Pet's Name", "First School");
        q1.getSelectionModel().selectFirst();
        Label answer1Label = new Label("********");
        TextField answer1Field = new TextField("Brisbane");
        answer1Field.setVisible(false);
        Button pencil3 = makePencil(() -> {
            if (!answer1Field.isVisible()) {
                answer1Field.setText(answer1Field.getText());
                answer1Label.setVisible(false);
                answer1Field.setVisible(true);
                answer1Field.requestFocus();
            } else {
                String value = answer1Field.getText().trim();
                if (!value.isEmpty()) {
                    answer1Label.setText("********");
                }
                answer1Field.setVisible(false);
                answer1Label.setVisible(true);
            }
        });
        HBox q1Box = new HBox(10, q1, answer1Label, answer1Field, pencil3);

        // ===== 安全问题 2 =====
        ComboBox<String> q2 = new ComboBox<>();
        q2.getItems().addAll("Favorite Color", "Favorite Movie", "First Car", "Best Friend", "Dream Job");
        q2.getSelectionModel().selectFirst();
        Label answer2Label = new Label("********");
        TextField answer2Field = new TextField("Blue");
        answer2Field.setVisible(false);
        Button pencil4 = makePencil(() -> {
            if (!answer2Field.isVisible()) {
                answer2Field.setText(answer2Field.getText());
                answer2Label.setVisible(false);
                answer2Field.setVisible(true);
                answer2Field.requestFocus();
            } else {
                String value = answer2Field.getText().trim();
                if (!value.isEmpty()) {
                    answer2Label.setText("********");
                }
                answer2Field.setVisible(false);
                answer2Label.setVisible(true);
            }
        });
        HBox q2Box = new HBox(10, q2, answer2Label, answer2Field, pencil4);

        // ===== 底部按钮 =====
        Button resetTypingBtn = new Button("Reset Typing Statistics");
        resetTypingBtn.setStyle("-fx-background-color: #FF6F61; -fx-text-fill: white; -fx-font-weight: bold;");

        Button resetLessonBtn = new Button("Reset Lesson Completion");
        resetLessonBtn.setStyle("-fx-background-color: #FF6F61; -fx-text-fill: white; -fx-font-weight: bold;");

        Button deleteAccountBtn = new Button("Delete Account");
        deleteAccountBtn.setStyle("-fx-background-color: #FF6F61; -fx-text-fill: white; -fx-font-weight: bold;");

        HBox bottomButtons = new HBox(20, resetTypingBtn, resetLessonBtn, deleteAccountBtn);
        bottomButtons.setAlignment(Pos.CENTER);

        popup.getChildren().addAll(headerBox, usernameBox, passwordBox, q1Box, q2Box, bottomButtons);

        root.getChildren().add(container);
    }

    // ===== Lesson History 页面 =====
    // ===== Lesson History 页面 =====
    private void showLessonHistoryPage(Stage stage) {
        BorderPane page = new BorderPane();
        page.setStyle("-fx-background-color: #0A002C;");

        // ---------- 顶部：标题 + 最佳成绩（左）/ Back（右） ----------
        // 大标题（左上角）
        Label title = new Label("LESSON HISTORY");
        title.setFont(Font.font("Jaro", FontWeight.EXTRA_BOLD, 60));
        title.setTextFill(Color.WHITE);

        // 标题下方的蓝色横线（跟着标题宽度变化，视觉更接近你给的图）
        Region titleRule = new Region();
        titleRule.setPrefHeight(3);
        titleRule.setStyle("-fx-background-color: #35A8FF;"); // 亮蓝
        // 让横线比标题略宽一点
        titleRule.prefWidthProperty().bind(title.widthProperty().add(40));

        VBox titleBox = new VBox(6, title, titleRule);
        titleBox.setAlignment(Pos.TOP_LEFT);

        // 最佳成绩
        Label best = new Label(
                "Personal Best Full Keyboard Result: 72 WPM at 99% accuracy (achieved 24/08/2025)"
        );
        best.setTextFill(Color.LIMEGREEN);
        best.setFont(Font.font("Jaro", FontWeight.BOLD, 24));

        // Back 按钮（右上角）
        Button back = new Button("Back");
        styleGreenPill(back);
        // 直接切回 profileScene；窗口大小保持为当前大小
        back.setOnAction(e -> stage.setScene(profileScene));

        // 标题在上，最佳成绩（左）和 Back（右）在下一行
        BorderPane bestAndBack = new BorderPane();
        bestAndBack.setLeft(best);
        bestAndBack.setRight(back);

        VBox topBox = new VBox(15, titleBox, bestAndBack);
        topBox.setPadding(new Insets(25, 25, 10, 25));
        page.setTop(topBox);

        // ---------- 中间：左侧历史记录（可滚动） + 右侧折线图 ----------
        // 左侧历史记录列表
        VBox historyList = new VBox(12,
                makeHistoryRow("Lesson 1f", "84 WPM", "24/08/2025", "4× ★"),
                makeHistoryRow("Lesson 4",  "42 WPM", "24/08/2025", "3× ★"),
                makeHistoryRow("AI Gen",    "22 WPM", "24/08/2025", "2× ★"),
                makeHistoryRow("AI Gen",    "90 WPM", "24/08/2025", "5× ★")
        );
        historyList.setPadding(new Insets(15));

        ScrollPane historyScroll = new ScrollPane(historyList);
        historyScroll.setFitToWidth(true);
        historyScroll.setPrefViewportHeight(420);
        historyScroll.setStyle("-fx-background: transparent; -fx-background-color: transparent;");

        // 灰色面板包裹
        VBox leftPanel = new VBox(15, historyScroll);
        leftPanel.setPadding(new Insets(15));
        leftPanel.setStyle("-fx-background-color: #D3D3D3; -fx-background-radius: 14;");
        leftPanel.setPrefWidth(560);

        // 导出按钮（左下）
        Button exportPdf = new Button("Export to PDF");
        styleGreenPill(exportPdf);
        Button exportCsv = new Button("Export to CSV");
        styleGreenPill(exportCsv);

        HBox exportRow = new HBox(20, exportPdf, exportCsv);
        exportRow.setAlignment(Pos.CENTER_LEFT);
        VBox leftColumn = new VBox(15, leftPanel, exportRow);
        leftColumn.setAlignment(Pos.TOP_LEFT);

        // 右侧折线图
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Date");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Value");
        LineChart<String, Number> chart = new LineChart<>(xAxis, yAxis);
        chart.setLegendVisible(false);
        chart.setTitle("Typing Statistics Trend (Sample)");
        chart.setPrefSize(600, 450);

        XYChart.Series<String, Number> s1 = new XYChart.Series<>();
        s1.getData().add(new XYChart.Data<>("2025-08-16", 45));
        s1.getData().add(new XYChart.Data<>("2025-08-17", 65));
        s1.getData().add(new XYChart.Data<>("2025-08-18", 72));
        s1.getData().add(new XYChart.Data<>("2025-08-19", 74));
        s1.getData().add(new XYChart.Data<>("2025-08-20", 48));
        s1.getData().add(new XYChart.Data<>("2025-08-21", 60));
        s1.getData().add(new XYChart.Data<>("2025-08-22", 70));

        XYChart.Series<String, Number> s2 = new XYChart.Series<>();
        s2.getData().add(new XYChart.Data<>("2025-08-16", 95));
        s2.getData().add(new XYChart.Data<>("2025-08-17", 95));
        s2.getData().add(new XYChart.Data<>("2025-08-18", 89));
        s2.getData().add(new XYChart.Data<>("2025-08-19", 100));
        s2.getData().add(new XYChart.Data<>("2025-08-20", 87));
        s2.getData().add(new XYChart.Data<>("2025-08-21", 92));
        s2.getData().add(new XYChart.Data<>("2025-08-22", 85));

        chart.getData().addAll(s1, s2);

        HBox center = new HBox(40, leftColumn, chart);
        center.setPadding(new Insets(25));
        center.setAlignment(Pos.TOP_LEFT);

        page.setCenter(center);

        // 场景大小继承当前窗口尺寸
        Scene historyScene = new Scene(page, stage.getWidth(), stage.getHeight());
        stage.setScene(historyScene);
    }


    // 历史记录行
    private HBox makeHistoryRow(String lesson, String wpm, String date, String stars) {
        Label lLesson = new Label(lesson);
        Label lWpm   = new Label(wpm);
        Label lDate  = new Label(date);
        Label lStars = new Label(stars);


        for (Label l : new Label[]{lLesson, lWpm, lDate, lStars}) {
            l.setFont(Font.font("Jaro", FontWeight.BOLD, 18));
            l.setStyle("-fx-text-fill: black;"); // 强制黑色
        }

        HBox row = new HBox(30, lLesson, lWpm, lDate, lStars);
        row.setPadding(new Insets(12));
        row.setStyle(
                "-fx-background-color: #F0F0F0;" +
                        "-fx-background-radius: 10;" +
                        "-fx-border-color: black;" +
                        "-fx-border-width: 2;" +
                        "-fx-border-radius: 10;"
        );
        return row;
    }


    // 绿色胶囊按钮样式
    private void styleGreenPill(Button b) {
        b.setStyle(
                "-fx-background-color: #7CFC00;" +
                        "-fx-text-fill: black;" +
                        "-fx-font-size: 20px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 22;" +
                        "-fx-padding: 10 26 10 26;"
        );
        b.setPrefWidth(300);
    }

    private Button makePencil(Runnable action) {
        Image img = new Image(getClass().getResourceAsStream("/pencil-write-tool-icon.png"));
        ImageView iv = new ImageView(img);
        iv.setFitWidth(20);
        iv.setFitHeight(20);
        Button b = new Button();
        b.setGraphic(iv);
        b.setStyle("-fx-background-color: transparent;");
        b.setOnAction(e -> action.run());
        return b;
    }

    // ========= 工具方法 =========
    private Label makeWhiteLabel(String text) {
        Label l = new Label(text);
        l.setTextFill(Color.WHITE);
        l.setFont(Font.font("Jaro", FontWeight.BOLD, 22));
        return l;
    }

    private Label makeGreenLabel(String text) {
        Label l = new Label(text);
        l.setTextFill(Color.LIMEGREEN);
        l.setFont(Font.font("Jaro", FontWeight.BOLD, 22));
        return l;
    }

    private Label makeGoldLabel(String text) {
        Label l = new Label(text);
        l.setTextFill(Color.GOLD);
        l.setFont(Font.font("Jaro", FontWeight.BOLD, 22));
        return l;
    }

    public static void main(String[] args) {
        launch();
    }
}
